from django.contrib import admin
from .models import Time,Present

# Register your models here.
admin.site.register(Time)
admin.site.register(Present)